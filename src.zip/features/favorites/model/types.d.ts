interface FavoriteLocation {
  id: string;
  name: string;
  alias?: string;
  lat: number;
  lon: number;
}
